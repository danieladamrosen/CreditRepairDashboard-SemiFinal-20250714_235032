import { useCallback } from 'react';

/**
 * Shared hook for smooth scrolling with standardized choreography timing
 * Supports both simple scrolling and callback-based choreography patterns
 * Uses requestAnimationFrame for optimal timing and proper animation chaining
 */
export const useSmoothScrollToNextCard = () => {
  const scrollToSection = useCallback((sectionSelector: string, callback?: () => void, delay: number = 0) => {
    const performScroll = () => {
      requestAnimationFrame(() => {
        // Handle data-section attribute selectors (without brackets)
        const targetSelector = sectionSelector.startsWith('[data-section=') 
          ? sectionSelector 
          : `[data-section="${sectionSelector}"]`;
        
        const targetSection = document.querySelector(targetSelector);
        
        if (targetSection) {
          console.log(`📍 Scrolling to section: ${targetSelector}`);
          const rect = targetSection.getBoundingClientRect();
          const targetScrollY = window.pageYOffset + rect.top - 20;
          
          window.scrollTo({ top: targetScrollY, behavior: 'smooth' });
          console.log(`✅ Scrolled to ${targetSelector} with 20px offset`);
          
          // Execute callback after scroll (500ms delay for choreography)
          if (callback) {
            setTimeout(() => {
              console.log(`🔄 Executing callback for ${targetSelector}`);
              callback();
              
              // After collapse, scroll to next section (500ms delay)
              setTimeout(() => {
                const nextSections = {
                  'personal-info': 'inquiries',
                  'inquiries': 'credit-accounts',
                  'credit-accounts': 'public-records'
                };
                
                const currentSection = sectionSelector.replace('[data-section="', '').replace('"]', '');
                const nextSection = nextSections[currentSection as keyof typeof nextSections];
                
                if (nextSection) {
                  console.log(`➡️ Auto-scrolling to next section: ${nextSection}`);
                  requestAnimationFrame(() => {
                    const nextElement = document.querySelector(`[data-section="${nextSection}"]`);
                    if (nextElement) {
                      const nextRect = nextElement.getBoundingClientRect();
                      const nextScrollY = window.pageYOffset + nextRect.top - 20;
                      window.scrollTo({ top: nextScrollY, behavior: 'smooth' });
                    }
                  });
                }
              }, 500);
            }, 500);
          }
        } else {
          console.warn(`❌ Section not found: ${targetSelector}`);
        }
      });
    };

    if (delay > 0) {
      setTimeout(performScroll, delay);
    } else {
      performScroll();
    }
  }, []);

  return { scrollToSection };
};