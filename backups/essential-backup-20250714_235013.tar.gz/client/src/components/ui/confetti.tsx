import { useEffect, useState } from 'react';

interface ConfettiPiece {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  rotation: number;
  rotationSpeed: number;
}

interface ConfettiProps {
  trigger: number;
  duration?: number;
  colors?: string[];
  particleCount?: number;
}

export function Confetti({
  trigger,
  duration = 3000,
  colors = ['#10B981', '#3B82F6', '#F59E0B', '#EF4444', '#8B5CF6', '#F97316'],
  particleCount = 50,
}: ConfettiProps) {
  const [particles, setParticles] = useState<ConfettiPiece[]>([]);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    if (trigger > 0) {
      // Reset particles first to ensure clean start
      setParticles([]);
      setIsActive(false);

      // Small delay to ensure reset, then start new animation
      setTimeout(() => {
        setIsActive(true);

        // Create particles
        const newParticles: ConfettiPiece[] = Array.from({ length: particleCount }, (_, i) => ({
          id: i + trigger * 1000, // Unique IDs to prevent conflicts
          x: Math.random() * 100,
          y: -10,
          vx: (Math.random() - 0.5) * 4,
          vy: Math.random() * 3 + 2,
          color: colors[Math.floor(Math.random() * colors.length)],
          size: Math.random() * 8 + 4,
          rotation: Math.random() * 360,
          rotationSpeed: (Math.random() - 0.5) * 10,
        }));

        setParticles(newParticles);

        // Clear after duration
        setTimeout(() => {
          setParticles([]);
          setIsActive(false);
        }, duration);
      }, 50);
    }
  }, [trigger, duration, colors, particleCount]);

  useEffect(() => {
    if (!isActive) return;

    let animationId: number;

    const animate = () => {
      setParticles((prev) => {
        if (prev.length === 0) return prev;

        return prev
          .map((particle) => ({
            ...particle,
            x: particle.x + particle.vx * 0.3,
            y: particle.y + particle.vy * 0.3,
            vy: particle.vy + 0.03, // gentle gravity
            rotation: particle.rotation + particle.rotationSpeed * 0.3,
          }))
          .filter((particle) => particle.y < 120); // Remove particles that fall off screen
      });

      if (isActive) {
        animationId = requestAnimationFrame(animate);
      }
    };

    animationId = requestAnimationFrame(animate);
    return () => {
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
    };
  }, [isActive]);

  if (!isActive || particles.length === 0) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute transition-transform duration-100"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: `${particle.size}px`,
            height: `${particle.size}px`,
            backgroundColor: particle.color,
            transform: `rotate(${particle.rotation}deg)`,
            borderRadius: Math.random() > 0.5 ? '50%' : '0%',
          }}
        />
      ))}
    </div>
  );
}
