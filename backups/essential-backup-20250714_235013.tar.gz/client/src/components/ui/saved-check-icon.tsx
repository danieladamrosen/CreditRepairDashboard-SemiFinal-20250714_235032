import { ThickCheckIcon } from './thick-check-icon';

interface SavedCheckIconProps {
  className?: string;
}

export function SavedCheckIcon({ className = "" }: SavedCheckIconProps) {
  return (
    <div className={`flex items-center justify-center w-8 h-8 rounded-full bg-green-600 ${className}`}>
      <ThickCheckIcon className="w-4 h-4 text-white" />
    </div>
  );
}