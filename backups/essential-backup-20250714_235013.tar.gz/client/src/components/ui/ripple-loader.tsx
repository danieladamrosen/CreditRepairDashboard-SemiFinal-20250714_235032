import { useState, useEffect } from 'react';
import { CloudyLoaderRipple } from './cloudy-loader-ripple';
import { CloudyLoaderBlur } from './cloudy-loader-blur';

interface RippleLoaderProps {
  className?: string;
}

export function RippleLoader({ className = '' }: RippleLoaderProps) {
  const [useRipple, setUseRipple] = useState(false);

  useEffect(() => {
    setUseRipple(Math.random() < 0.5);
  }, []);

  if (useRipple) {
    return <CloudyLoaderRipple className={className} />;
  }

  return <CloudyLoaderBlur className={className} />;
}